from django.contrib import admin
from .models import Campaign, SendCampaign, CampaignReport

class CampaignAdmin(admin.ModelAdmin):
    list_display = ('id', 'campaign_name', 'campaign_type', 'is_active')
    list_filter = ('campaign_type', 'is_active')
    search_fields = ('campaign_name', 'id')

class SendCampaignAdmin(admin.ModelAdmin):
    list_display = ('id', 'campaign', 'sent_count', 'status')
    list_filter = ('status', 'campaign')
    search_fields = ('campaign__campaign_name', 'id')

class CampaignReportAdmin(admin.ModelAdmin):
    list_display = ('id', 'campaign', 'campaign_name', 'target_contact_number', 'status', 'last_update')
    # Note: Filtering by plain CharFields (like campaign_name) may require a custom filter.
    list_filter = ('id', 'campaign_name', 'last_update')
    search_fields = ('campaign_name', 'target_contact_number', 'id')

admin.site.register(Campaign, CampaignAdmin)
admin.site.register(SendCampaign, SendCampaignAdmin)
admin.site.register(CampaignReport, CampaignReportAdmin)
