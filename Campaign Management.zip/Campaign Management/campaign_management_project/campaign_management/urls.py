from django.urls import path
from .views import CampaignSendAPIView  # Import the API view
from .views import CampaignReportBulkUpdateAPIView

urlpatterns = [
    # Your other URL patterns here...

    # Add the URL pattern for the send_campaign API
    path('send_campaign/', CampaignSendAPIView.as_view(), name='send_campaign'),
    path('api/campaign-reports/bulk-update/', CampaignReportBulkUpdateAPIView.as_view(), name='campaign-report-bulk-update'),
]
