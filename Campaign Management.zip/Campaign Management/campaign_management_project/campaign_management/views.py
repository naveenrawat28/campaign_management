from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth.models import User
from .models import SendCampaign, CampaignReport
import json
import logging

logger = logging.getLogger(__name__)

class CampaignSendAPIView(APIView):

    def post(self, request, *args, **kwargs):
        username = request.data.get('username')
        campaign_id = request.data.get('campaign_id')
        batch_size = request.data.get('batch_size')
        try:
            batch_size = int(batch_size)
            if batch_size <= 0:
                return Response({"error": "Invalid batch_size. Please provide a positive integer."},
                                status=status.HTTP_400_BAD_REQUEST)
        except (TypeError, ValueError):
            return Response({"error": "Invalid batch_size. Please provide a valid positive integer."},
                            status=status.HTTP_400_BAD_REQUEST)

        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Retrieve the SendCampaign based on the campaign's id from the Campaign table.
            send_campaign = SendCampaign.objects.get(campaign__id=campaign_id, status=True)
        except SendCampaign.DoesNotExist:
            return Response({"error": "Campaign not found or not active"}, status=status.HTTP_400_BAD_REQUEST)

        unsent_numbers = send_campaign.get_unsent_numbers()
        if not unsent_numbers:
            return Response({"message": "All numbers have been sent already."},
                            status=status.HTTP_200_SUCCESS_REQUEST)

        if len(unsent_numbers) < batch_size:
            batch_size = len(unsent_numbers)

        numbers_to_send = unsent_numbers[:batch_size]
        send_campaign.update_sent_count(len(numbers_to_send))

        response_data = []
        for number in numbers_to_send:
            # Create a CampaignReport record for each number sent.
            CampaignReport.objects.create(
                campaign=send_campaign.campaign,
                campaign_name=send_campaign.campaign.campaign_name,
                target_contact_number=number,
                status=False  # default; update later as needed.
            )
            
            response_data.append({
                "campaign_name": send_campaign.campaign.campaign_name,
                "campaign_type": send_campaign.campaign.campaign_type,
                "campaign_text": send_campaign.campaign.campaign_text,
                "media_file_url": send_campaign.campaign.media_file.url if send_campaign.campaign.media_file else None,
                "target_contact_number": number  
            })

        return Response(response_data, status=status.HTTP_200_OK)



############################################################################################################


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import CampaignReport, Campaign

class CampaignReportBulkUpdateAPIView(APIView):
    """
    Updates the 'status' of multiple phone numbers in CampaignReport
    based on the JSON array provided in the request body.
    """
    def patch(self, request, *args, **kwargs):
        # The request data is expected to be a list of objects:
        # [
        #   {
        #     "campaign_name": "...",
        #     "numbers_with_status": {
        #         "phone_number": true/false,
        #         ...
        #     }
        #   },
        #   ...
        # ]
        campaigns_data = request.data

        if not isinstance(campaigns_data, list):
            return Response(
                {"error": "Expected a list of campaigns."},
                status=status.HTTP_400_BAD_REQUEST
            )

        updated_reports = []
        errors = []

        for campaign_data in campaigns_data:
            campaign_name = campaign_data.get("campaign_name")
            numbers_with_status = campaign_data.get("numbers_with_status")

            # Basic validation
            if not campaign_name or not isinstance(numbers_with_status, dict):
                errors.append(
                    f"Invalid data for campaign: {campaign_data}"
                )
                continue

            # For each number in numbers_with_status, update or create the record
            for number_str, new_status in numbers_with_status.items():
                # Validate new_status is boolean
                if not isinstance(new_status, bool):
                    errors.append(
                        f"Invalid status for number '{number_str}' in campaign '{campaign_name}'. Must be boolean."
                    )
                    continue

                try:
                    # Attempt to find an existing CampaignReport by campaign_name + number
                    # If you rely on the 'campaign' ForeignKey, you might want to do:
                    #   campaign_obj = Campaign.objects.get(campaign_name=campaign_name)
                    #   report = CampaignReport.objects.get(campaign=campaign_obj, target_contact_number=number_str)
                    report = CampaignReport.objects.get(
                        campaign_name=campaign_name,
                        target_contact_number=number_str
                    )
                    # Update the status
                    report.status = new_status
                    report.save()  # triggers last_update auto-update
                    updated_reports.append(report.id)

                except CampaignReport.DoesNotExist:
                    errors.append(
                        f"No matching report found for campaign '{campaign_name}', number '{number_str}'."
                    )

        response_data = {
            "updated_reports_count": len(updated_reports),
            "errors": errors,
        }
        return Response(response_data, status=status.HTTP_200_OK)



