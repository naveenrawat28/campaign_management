import json
from django.db import models
from django.core.exceptions import ValidationError

class Campaign(models.Model):
    CAMPAIGN_CHOICES = [
        ('txt', 'Text Campaign'),
        ('media', 'Media Campaign'),
    ]
    
    campaign_name = models.CharField(max_length=255)
    campaign_type = models.CharField(
        max_length=5,
        choices=CAMPAIGN_CHOICES,
        default='txt', 
    )
    campaign_text = models.TextField(null=True, blank=True) 
    media_file = models.FileField(upload_to='media_campaigns/', null=True, blank=True) 
    is_active = models.BooleanField(default=True) 
    
    def save(self, *args, **kwargs):
        if self.campaign_type == 'txt':
            self.media_file = None 
        super().save(*args, **kwargs) 
    
    def __str__(self):
        return self.campaign_name

##########################################################################

class SendCampaign(models.Model):
    campaign = models.ForeignKey(
        'Campaign',
        on_delete=models.CASCADE,
        limit_choices_to={'is_active': True},
        related_name='selected_campaigns',
        verbose_name="Campaign Name"
    )
    
    target_contact_numbers = models.TextField(help_text="Enter numbers, each on a new line.")  
    status = models.BooleanField(default=False)  
    sent_count = models.IntegerField(default=0)

    def save(self, *args, **kwargs):
        if self.target_contact_numbers:
            tcn = self.target_contact_numbers.strip()
            if not (tcn.startswith('[') and tcn.endswith(']')):
                contact_numbers_list = tcn.splitlines()
                contact_numbers_list = [number.strip() for number in contact_numbers_list if number.strip()]
                self.target_contact_numbers = json.dumps(contact_numbers_list)
        else:
            raise ValidationError("Target contact numbers must be provided.")
        
        super().save(*args, **kwargs)


    def __str__(self):
        return f"Selected Campaign: {self.campaign.campaign_name}"

    def get_unsent_numbers(self):
        """
        Returns the unsent numbers as a list, based on sent_count.
        """
        numbers = json.loads(self.target_contact_numbers)  
        return numbers[self.sent_count:]
    
    def update_sent_count(self, count):
        """
        Updates the sent_count by adding the provided count.
        """
        self.sent_count += count
        self.save()
        return self.sent_count

########################################################################

from django.db import models
from django.utils import timezone

class CampaignReport(models.Model):
    campaign = models.ForeignKey(
        'Campaign',
        on_delete=models.CASCADE,
        related_name='reports'
    )
    campaign_name = models.CharField(max_length=255)
    target_contact_number = models.CharField(max_length=50)
    status = models.BooleanField(default=False)
    last_update = models.DateTimeField(auto_now=True)


    def __str__(self):
        return f"{self.campaign_name} - {self.target_contact_number}"
